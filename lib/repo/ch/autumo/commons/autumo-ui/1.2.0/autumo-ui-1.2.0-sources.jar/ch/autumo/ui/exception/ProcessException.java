/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.exception;

/**
 * Exception for any wrong processings. 
 */
public class ProcessException extends Exception {

	private static final long serialVersionUID = 1L;
	
	/** Error code: Reading resource failed. */
	public static int ERR_CODE_RESOURCE_READ_FAILED = 1;
	/** Error code: Copying resource failed. */
    public static int ERR_CODE_RESOURCE_COPY_FAILED = 2;
	/** Error code: Writing a script/file output failed. */
    public static int ERR_CODE_WRITE_SCRIPT = 5;
	/** Error code: Writing to a log-file failed. */
    public static int ERR_CODE_WRITE_LOG_FILE = 8;
	/** Error code: Copying a project failed. */
    public static int ERR_CODE_COPY_PROJECT_FAILED = 9;
	/** Error code: General process error. */
    public static int ERR_CODE_PROCESS = 99;
    
    /**
     * Error code.
     */
    private int errCode = 0;

    /**
     * Process exception.
     * @param errCode error code
     */
    public ProcessException(int errCode) {
        super();
        this.errCode = errCode;
    }

    /**
     * Process exception.
     * @param errCode error code
     * @param message message
     */
    public ProcessException(int errCode, String message) {
        super(message);
        this.errCode = errCode;
    }

    /**
     * Get error code.
     * @return error code
     */
    public int getErrCode() {
        return errCode;
    }

    /**
     * Set error code.
     * @param errCode error code
     */
    public void setErrCode(int errCode) {
        this.errCode = errCode;
    }

}
