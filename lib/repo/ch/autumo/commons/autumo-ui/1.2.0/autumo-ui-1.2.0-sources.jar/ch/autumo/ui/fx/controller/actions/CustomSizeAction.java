/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.controller.actions;

import javafx.stage.Modality;

/**
 * Custom Windows-Size Action.
 */
public abstract class CustomSizeAction extends BaseAction {

	private int width = 800;
	private int height = 600;

	/**
	 * Custom size action.
	 */
	public CustomSizeAction() {
	}
	
	/**
	 * Custom size action.
	 * 
	 * @param width width
	 * @param height height
	 */
	public CustomSizeAction(int width, int height) {
		this.width = width;
		this.height = height;
	}

	/**
	 * Custom size action.
	 * 
	 * @param width width
	 * @param height height
	 * @param modality window modality
	 */
	public CustomSizeAction(int width, int height, Modality modality) {
		super(modality);
		this.width = width;
		this.height = height;
	}
	
	/**
	 * Set width.
	 * 
	 * @param width width
	 */
	public void setWidth(int width) {
		this.width = width;
	}

	/**
	 * Set height.
	 * 
	 * @param height height
	 */
	public void setHeight(int height) {
		this.height = height;
	}

	/**
	 * Get width.
	 * 
	 * @return width
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * Get height.
	 * 
	 * @return height
	 */
	public int getHeight() {
		return height;
	}

}
