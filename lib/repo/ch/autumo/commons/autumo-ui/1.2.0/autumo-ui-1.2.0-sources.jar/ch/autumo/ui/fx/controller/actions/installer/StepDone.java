/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.controller.actions.installer;

import ch.autumo.ui.utils.Helper;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;

/**
 * Done Installer Step.
 */
public class StepDone extends BaseStep {

	/**
	 * Default constructor.
	 */
	public StepDone() {
	}
	
	@Override
	public void execute() {
		
		final BorderPane pane = controller.getBody();
		// Individual insets, depending on the element that is placed!
		BorderPane.setMargin(pane, new Insets(0, 10, 0, 10));
		
		final Label info = new Label(Helper.getTranslatedText(super.getApp(), "Installer.done.info"));
		info.setFont(new Font(14));
		pane.setLeft(info);
		
		final Button finish = controller.getFooterButton();
		finish.setText(Helper.getTranslatedText(super.getApp(), "Installer.finish"));
		finish.setOnAction(_ -> {
			ic.finish();
    	});
		
		final BorderPane buttons = controller.getFooterButtons();
		final Button back = new Button(Helper.getTranslatedText(super.getApp(), "Installer.back"));
		BorderPane.setMargin(back, new Insets(0, 8, 0, 0));
		back.setPrefWidth(100);
		back.setMinWidth(100);
		back.getStyleClass().add("default-info-footer-button");
		buttons.setCenter(back);
		back.setOnAction(_ -> {
			super.getInstallationController().back();
    	});	
	}

	@Override
	public String getTitle() {
		return Helper.getTranslatedText(super.getApp(), "Installer.done.title");
	}
	
}
