/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.controller.actions.installer;

import ch.autumo.ui.exception.ProcessException;

/**
 * Task listener for installation controller.
 */
public interface InstallEndListener {

	/**
	 * Will be called when the installer is finished.
	 * 
	 * @param ex an exception if any or null
	 */
    public void completed(ProcessException ex);
    
}
