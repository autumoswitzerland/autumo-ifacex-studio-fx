/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.controller.actions.installer;

import ch.autumo.ui.fx.BaseApp;

/**
 * Installation Controller interface.
 */
public interface InstallationController {

	/**
	 * Start the installation.
	 */
    public void start();
    
    /**
     * Next: Called by a step.
     */
    public void next();
    
    /**
     * Back: Called by a step.
     */
    public void back();
    
    /**
     * Finish: Called by last step!
     */
    public void finish();
    
    /**
     * Get the application reference.
     * 
     * @return application
     */
    public BaseApp getApp();
    
}
