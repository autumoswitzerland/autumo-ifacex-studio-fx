/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.control;

import ch.autumo.commons.application.LicensedApplication;
import ch.autumo.commons.utils.UtilsException;
import ch.autumo.commons.utils.security.CryptUtils;
import ch.autumo.ui.fx.BaseApp;
import ch.autumo.ui.utils.Helper;
import ch.autumo.ui.utils.UI;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ReadOnlyIntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;

/**
 * A secret/password field with a toggle to show/hide the value and an optional
 * in-place encoder (mode combobox) that encodes the password using the
 * application's security key (unique key by default).
 * 
 * <p>The encoder is enabled when a mode &gt; 0 is selected; encoding uses the
 * unique security key ({@code app.getUniqueSecurityKey()}) unless
 * {@code internalEncryption} is {@code true}.</p>
 */
public class SecretField extends HBox {

    private final LicensedApplication licApp;
    private final BaseApp app;
    private final boolean internalEncryption;

    private final PasswordField masked = new PasswordField();
    private final TextField plain = new TextField();
    private final StackPane fieldBox = new StackPane(masked, plain);
    private final Button revealBtn = new Button();
    private final Label encLabel = new Label();
    private final ComboBox<String> encCombo = new ComboBox<>(EncoderModes.getDefault());
    private final StringProperty value = new SimpleStringProperty("");
    private final IntegerProperty encMode = new SimpleIntegerProperty(0);
    private boolean encoding = false;
    private boolean revealed = false;

    /**
     * Creates a secret field with unique-key encryption (default).
     * 
     * @param app the application
     * @param licApp licensed application from autumo commons or <code>null</code>
     * @return the new secret field
     */
    public static SecretField create(BaseApp app, LicensedApplication licApp) {
        return SecretField.create(app, licApp, false);
    }
    
    /**
     * Creates a secret field with unique-key encryption (default).
     * 
     * @param app the application
     * @return the new secret field
     */
    public static SecretField create(BaseApp app) {
        return SecretField.create(app, false);
    }

    /**
     * Creates a secret field.
     * 
     * @param app the application
     * @param licApp licensed application from autumo commons or <code>null</code>
     * @param internalEncryption if {@code true}, use the internal security key
     * @return the new secret field
     */
    public static SecretField create(BaseApp app, LicensedApplication licApp, boolean internalEncryption) {
        final SecretField field = new SecretField(app, licApp, internalEncryption);
        field.init();
        return field;
    }
    
    /**
     * Creates a secret field.
     * 
     * @param app the application
     * @param internalEncryption if {@code true}, use the internal security key
     * @return the new secret field
     */
    public static SecretField create(BaseApp app, boolean internalEncryption) {
        final SecretField field = new SecretField(app, internalEncryption);
        field.init();
        return field;
    }

    private SecretField(BaseApp app, LicensedApplication licApp, boolean internalEncryption) {
        this.app = app;
        this.licApp = licApp;
        this.internalEncryption = internalEncryption;
    }
    
    private SecretField(BaseApp app, boolean internalEncryption) {
        this.app = app;
        this.licApp = null;
        this.internalEncryption = internalEncryption;
    }

    private void init() {
        setSpacing(6);
        setPadding(new Insets(0));
        setAlignment(Pos.CENTER_LEFT);

        plain.setVisible(false);
        plain.setManaged(false);
        masked.setMinWidth(160);
        masked.setPrefWidth(200);
        plain.setMinWidth(160);
        plain.setPrefWidth(200);

        fieldBox.getChildren().setAll(masked, plain);
        HBox.setMargin(fieldBox, new Insets(0));

        revealBtn.setPrefHeight(26);
        revealBtn.setMinWidth(32);
        final javafx.scene.text.Text revealIcon = Icons.create("eye", 16);
        if (revealIcon != null) {
            revealIcon.setStyle("-fx-fill: #dddddd;");
            revealBtn.setGraphic(revealIcon);
            revealBtn.setText(null);
        } else {
            revealBtn.setText("");
        }
        revealBtn.setOnAction(_ -> toggleReveal());

        encLabel.setText(Helper.getTranslatedText(app, "Encoder.label.enc"));
        encLabel.getStyleClass().add("field-label");
        encLabel.setAlignment(Pos.CENTER_LEFT);
        encLabel.setMaxHeight(Double.MAX_VALUE);
        encCombo.setPrefHeight(26);
        encCombo.setMinWidth(160);
        encCombo.setOnAction(_ -> encodeIfNeeded());
        encCombo.valueProperty().addListener((_, _, newV) -> {
            // Sync the mode whenever the selection changes - programmatic (e.g. setEncMode
            // when a configuration is loaded) or user interaction. Never encode here:
            // encoding only happens in setOnAction (user clicks a mode in the combo box).
            final int e = newV == null ? 0 : modeOf(newV.toString());
            encMode.set(e < 0 ? 0 : e);
        });

        masked.textProperty().addListener((_, _, newV) -> {
            if (revealed) {
                plain.setText(newV);
            }
            value.set(newV);
        });
        plain.textProperty().addListener((_, _, newV) -> {
            if (!revealed) {
                masked.setText(newV);
            }
            value.set(newV);
        });

        getChildren().addAll(fieldBox, revealBtn, encLabel, encCombo);

        // The password field fills the available width, the reveal button and the encryption
        // dropdown keep their natural size so the mode stays readable and does not jump around.
        fieldBox.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(fieldBox, Priority.ALWAYS);
        HBox.setHgrow(revealBtn, Priority.NEVER);
        HBox.setHgrow(encLabel, Priority.NEVER);
        HBox.setHgrow(encCombo, Priority.NEVER);
        encCombo.setMaxWidth(Region.USE_PREF_SIZE);
    }

    private void toggleReveal() {
        revealed = !revealed;
        if (revealed) {
            plain.setText(masked.getText());
            masked.setVisible(false);
            masked.setManaged(false);
            plain.setVisible(true);
            plain.setManaged(true);
            plain.requestFocus();
            final javafx.scene.text.Text hideIcon = Icons.create("eye-slash", 16);
            if (hideIcon != null) {
                hideIcon.setStyle("-fx-fill: #dddddd;");
                revealBtn.setGraphic(hideIcon);
                revealBtn.setText(null);
            } else {
                revealBtn.setText("");
            }
        } else {
            masked.setText(plain.getText());
            plain.setVisible(false);
            plain.setManaged(false);
            masked.setVisible(true);
            masked.setManaged(true);
            masked.requestFocus();
            final javafx.scene.text.Text showIcon = Icons.create("eye", 16);
            if (showIcon != null) {
                showIcon.setStyle("-fx-fill: #dddddd;");
                revealBtn.setGraphic(showIcon);
                revealBtn.setText(null);
            } else {
                revealBtn.setText("");
            }
        }
    }

    private void encodeIfNeeded() {
        if (encoding) {
            // The encoder is already running: the value is encoded once, not again. The same
            // holds when the mode comes from the outside - the value is already encoded then.
            return;
        }
        encoding = true;
        try {
            encode();
        } finally {
            encoding = false;
        }
    }

    /**
     * Encodes the value with the mode of the list.
     */
    private void encode() {
        if (encCombo.getValue() == null) {
            return;
        }
        String val = encCombo.getValue().toString();
        if (val.isBlank()) {
            return;
        }
        final int e = modeOf(val);
        if (e < 0) {
            return;
        }
        if (e == 0) {
            // "none": the field holds the plain value again - an encoded value goes.
            final boolean wasEncoded = encMode.get() > 0;
            encMode.set(0);
            if (wasEncoded) {
                setText("");
            }
            setEditable(true);
            setBackgroundColor(85, 85, 85);
            return;
        }
        String current = value.get();
        if (current == null || current.isBlank()) {
            encMode.set(0);
            encCombo.setValue("0: none");
            setEditable(true);
            setBackgroundColor(85, 85, 85);
            return;
        }
        
        
        String secKey = null;
		if (licApp != null) {
			secKey = licApp.getUniqueSecurityKey();			
		} else {
			secKey = app.getUniqueSecurityKey();			
		}
		
		// Invalid external security key
        if (!internalEncryption && (secKey == null || secKey.length() != 32)) {
        	if (licApp != null) {
        		UI.showFineWarningDialog(app, Helper.getTranslatedText(app, "Encoder.enc.additional.err"));
        	} else {
        		UI.showFineWarningDialog(app, Helper.getTranslatedText(app, "Encoder.enc.err1"));
        	}
            encMode.set(0);
            encCombo.setValue("0: none");
            setEditable(true);
            setBackgroundColor(85, 85, 85);
            return;
        }
        
		// Valid keys: encode
        String newVal = null;
        try {
    		if (licApp != null) {
    			newVal = CryptUtils.encode(e, current, licApp, internalEncryption);			
    		} else {
    			newVal = CryptUtils.encode(e, current, app, internalEncryption);
    		}
			if (newVal != null && newVal.length() > 1) {
				newVal = newVal.substring(2, newVal.length());
			}
        } catch (UtilsException ex) {
            UI.showError(app, ex, Helper.getTranslatedText(app, "Encoder.enc.err2"));
            encMode.set(0);
            encCombo.setValue("0: none");
            setEditable(true);
            setBackgroundColor(85, 85, 85);
            return;
        }
        encMode.set(e);
        final String mode = encCombo.getValue().toString();
        final ObservableList<String> tempOptions = FXCollections.observableArrayList(
                mode,
                "0: none"
        );
        encCombo.setItems(tempOptions);
        // The new list holds the mode and "none" only: the mode stays selected.
        encCombo.setValue(mode);
        encCombo.getSelectionModel().selectFirst();
        setText(newVal);
        setEditable(false);
        setBackgroundColor(14, 78, 116);
    }

    
    /**
     * The mode of an entry of the mode list: the number in front of the colon
     * ({@code 3: Base64 - PBE MD5 DES} is the mode 3).
     *
     * @param entry the entry of the mode list
     * @return the mode, -1 if the entry has no mode
     */
    private static int modeOf(String entry) {
        final int colon = entry.indexOf(':');
        if (colon < 1) {
            return -1;
        }
        try {
            return Integer.parseInt(entry.substring(0, colon).trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private void setBackgroundColor(int r, int g, int b) {
        BackgroundFill bf = new BackgroundFill(Color.rgb(r, g, b), null, null);
        masked.setBackground(new Background(bf));
        plain.setBackground(new Background(bf));
    }

    /**
     * Returns the current text value.
     * 
     * @return the text
     */
    public String getText() {
        return value.get();
    }

    /**
     * Sets the text value.
     * 
     * @param text the text to set
     */
    public void setText(String text) {
        masked.setText(text);
        plain.setText(text);
        value.set(text);
    }

    /**
     * Returns the text property.
     * 
     * @return text property
     */
    public StringProperty textProperty() {
        return value;
    }

    /**
     * Returns the selected encryption mode.
     *
     * <p>0 if nothing is encoded.</p>
     *
     * @return the encryption mode
     */
    public int getEncMode() {
        return encMode.get();
    }

    /**
     * Returns the encryption mode property.
     *
     * <p>It changes when the mode of the field changes - also when it is set with
     * {@link #setEncMode(int)}.</p>
     *
     * @return the encryption mode property
     */
    public ReadOnlyIntegerProperty encModeProperty() {
        return encMode;
    }

    /**
     * Selects an encryption mode without encoding the value.
     *
     * <p>Used when a configuration is loaded: the value is already encoded, it must not be
     * encoded again. The mode is selected in the list of the field, a mode that is not one of
     * the standard ones is added to the list.</p>
     *
     * @param mode the encryption mode (0 for none)
     */
    public void setEncMode(int mode) {
        encoding = true;
        try {
            if (mode <= 0) {
                this.encCombo.setValue("0: none");
                encMode.set(0);
                setEditable(true);
                setBackgroundColor(85, 85, 85);
                return;
            }
            final String option = optionFor(mode);
            this.encCombo.setValue(option);
            // Explicitly select in the selection model so the dropdown shows the
            // configured mode even before the field is first shown.
            this.encCombo.getSelectionModel().select(option);
            encMode.set(mode);
            setEditable(false);
            setBackgroundColor(14, 78, 116);
        } finally {
            encoding = false;
        }
    }

    /**
     * The list entry of a mode: the standard entry of the mode or - for a mode that is not one
     * of them - a new entry that is added to the list.
     *
     * @param mode the encryption mode
     * @return the list entry of the mode
     */
    private String optionFor(int mode) {
        for (final String option : this.encCombo.getItems()) {
            if (modeOf(option) == mode) {
                return option;
            }
        }
        final String option = mode + ": mode " + mode;
        if (!this.encCombo.getItems().contains(option)) {
            this.encCombo.getItems().add(option);
        }
        return option;
    }

    /**
     * Sets whether the field is editable.
     * 
     * @param editable true if editable
     */
    public void setEditable(boolean editable) {
        masked.setEditable(editable);
        plain.setEditable(editable);
    }

    /**
     * Returns whether the field is editable.
     * 
     * @return true if editable
     */
    public boolean isEditable() {
        return masked.isEditable();
    }

}
