/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.model;

import javafx.scene.layout.Pane;

/**
 * Default Pane Model; the model of every pane built on the default pane
 * layout (header, body, footer), e.g. {@link ch.autumo.ui.fx.view.DefaultInfoView}
 * or {@link ch.autumo.ui.fx.view.DefaultCodeEditorView}.
 */
public class DefaultPaneModel extends BaseModel {

	/**
	 * Model.
	 *
	 * @param view the view
	 */
	public DefaultPaneModel(Pane view) {
		super(view);
	}

}
