/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.controller.actions;

import ch.autumo.ui.fx.BaseApp;
import ch.autumo.ui.fx.controller.DefaultInfoController;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * Action interface for panes.
 */
public interface Action {

	/**
	 * Get the application
	 * 
	 * @return application
	 */
	public BaseApp getApp();

	/**
	 * Set the application.
	 * 
	 * @param app application
	 */
	public void setApp(BaseApp app);
	
	/**
	 * Get controller.
	 * 
	 * @return controller
	 */
	public DefaultInfoController getController();

	/**
	 * Set controller.
	 * 
	 * @param controller controller
	 */
	public void setController(DefaultInfoController controller);

	/**
	 * Get stage.
	 * 
	 * @return stage
	 */
	public Stage getStage();
	
	/**
	 * Get scene.
	 * 
	 * @return scene
	 */
	public Scene getScene();
	
	/**
	 * Get window modality.
	 * 
	 * @return window modality
	 */
	public Modality getStageModality();
	
	/**
	 * Inner execution.
	 */
	public void run();
	
	/**
	 * Execute the action.
	 */
	public void execute();
	
}
