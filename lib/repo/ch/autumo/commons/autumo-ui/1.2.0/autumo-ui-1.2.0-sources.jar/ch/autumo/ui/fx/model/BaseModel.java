/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.model;

import javafx.scene.layout.Pane;

/**
 * FX Base Model.
 */
public abstract class BaseModel {

	/** The view. */
	protected Pane view;

	/**
	 * Base Model.
	 * 
	 * @param view the view
	 */
	public BaseModel(Pane view) {
		this.view = view;
	}
	
	/**
	 * Get view.
	 * @return view
	 */
	public Pane getView() {
		return view;
	}
	
}
