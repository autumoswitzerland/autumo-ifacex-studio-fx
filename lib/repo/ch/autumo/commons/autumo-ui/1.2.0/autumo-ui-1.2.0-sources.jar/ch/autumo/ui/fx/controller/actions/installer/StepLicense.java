/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.controller.actions.installer;

import ch.autumo.ui.utils.Helper;
import ch.autumo.ui.utils.UI.HyperLinkRedirectListener;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.web.WebView;


/**
 * License Accept Installer Step.
 */
public class StepLicense extends BaseStep {
	
	/**
	 * Default constructor.
	 */
	public StepLicense() {
	}
	
	@Override
	public void execute() {
		
		final BorderPane pane = controller.getBody();
		// Individual insets, depending on the element that is placed!
		BorderPane.setMargin(pane, new Insets(0, 6, 0, 6));
		
		final GridPane grid = new GridPane();
		pane.setStyle("-fx-border-color: #555555");
		pane.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		
		final WebView webView = Helper.createWebView(app);
		webView.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		webView.getEngine().getLoadWorker().stateProperty().addListener(new HyperLinkRedirectListener(webView));
		webView.getEngine().setUserStyleSheetLocation(getHTMLStyleSheetLocation());
		webView.getEngine().load(Helper.getAppResource(app, "html/license_en.html"));
		
		GridPane.setVgrow(webView, Priority.ALWAYS);
		GridPane.setHgrow(webView, Priority.ALWAYS);
		grid.add(webView, 0, 0);
		pane.setCenter(grid);

		final BorderPane buttons = controller.getFooterButtons();
		final Button back = new Button(Helper.getTranslatedText(super.getApp(), "Installer.back"));
		BorderPane.setMargin(back, new Insets(0, 8, 0, 0));
		back.setPrefWidth(100);
		back.setMinWidth(100);
		back.getStyleClass().add("default-info-footer-button");
		buttons.setCenter(back);
		back.setOnAction(_ -> {
			super.getInstallationController().back();
    	});	
		
		Button next = controller.getFooterButton();
		next.setText(Helper.getTranslatedText(super.getApp(), "Installer.next"));
		next.setOnAction(_ -> {
			super.getInstallationController().next();
    	});
		next.setDisable(true);
		
		// replace empty label
		BorderPane footer = controller.getFooter();
		CheckBox accepted = new CheckBox(Helper.getTranslatedText(super.getApp(), "Installer.lic.accept"));
		accepted.getStyleClass().add("license-check-box");
		accepted.setPadding(new Insets(20, 0, 0, 8));
		accepted.setSelected(false);
		accepted.setOnAction(_ -> {
			if (accepted.isSelected())
				next.setDisable(false);
			else
				next.setDisable(true);				
    	});
		
		footer.setLeft(accepted);
	}

	@Override
	public void steppedOver() {
		super.getApp().licenseAccepted();
	}

	@Override
	public String getTitle() {
		return Helper.getTranslatedText(super.getApp(), "Installer.lic.title");
	}

	/**
	 * Returns the location of the HTML style sheet.
	 * Override to provide a custom style sheet.
	 *
	 * @return the CSS location
	 */
	public String getHTMLStyleSheetLocation() {
		return Helper.getBaseHTMLStyle();
	}

}
