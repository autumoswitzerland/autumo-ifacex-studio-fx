/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.controller.actions.installer;

import ch.autumo.ui.utils.Helper;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;

/**
 * Last dummy step.
 */
public class StepDummyLast extends BaseStep {

	/**
	 * Default constructor.
	 */
	public StepDummyLast() {
	}
	
	@Override
	public void execute() {
		final BorderPane pane = controller.getBody();
		pane.setCenter(new Label("Last Dummy Step"));
		
		Button next = controller.getFooterButton();
		next.setText(Helper.getTranslatedText(super.getApp(), "Installer.finish"));
		next.setOnAction(_ -> {
			ic.finish();
    	});
		
		final BorderPane buttons = controller.getFooterButtons();
		final Button back = new Button(Helper.getTranslatedText(super.getApp(), "Installer.back"));
		BorderPane.setMargin(back, new Insets(0, 8, 0, 0));
		back.setPrefWidth(100);
		back.setMinWidth(100);
		back.getStyleClass().add("default-info-footer-button");
		buttons.setCenter(back);
		back.setOnAction(_ -> {
			super.getInstallationController().back();
    	});	
	}

	@Override
	public String getTitle() {
		return "Last Dummy Step";
	}
	
}
