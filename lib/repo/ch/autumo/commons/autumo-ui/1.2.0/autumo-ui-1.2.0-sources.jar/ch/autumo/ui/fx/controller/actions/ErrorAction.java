/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.controller.actions;

import java.io.PrintWriter;
import java.io.StringWriter;

import ch.autumo.ui.fx.control.HTMLLabel;
import javafx.geometry.Insets;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;

/**
 * Error action.
 */
public class ErrorAction extends BaseAction {

	private Throwable ex;
	private String msg;
	
	/**
	 * Error action.
	 * @param ex throwable
	 */
	public ErrorAction(Throwable ex) {
		this.ex = ex;
	}

	/**
	 * Error action.
	 * @param msg message
	 */
	public ErrorAction(String msg) {
		this.msg = msg;
	}
	
	@Override
	public void execute() {
		final BorderPane pane = controller.getBody();
		// Individual insets, depending on the element that is placed!
		BorderPane.setMargin(pane, new Insets(0, 6, 0, 6));
		// Default: show exception
		if (msg == null) {
			final StringWriter sw = new StringWriter();
			final PrintWriter pw = new PrintWriter(sw);
			ex.printStackTrace(pw);
			pw.flush();
			final String exceptionText = sw.toString();
			final TextArea ta = new TextArea();
			ta.setText(exceptionText);
			ta.getStyleClass().add("exception-text-area");
			pane.setCenter(ta);
		} else {
			final HTMLLabel label = new HTMLLabel();
			label.setText(msg);
			label.setStyle(this.getLabelStyle());
			pane.setTop(label);
		}
	}

	/**
	 * Get style for message label.
	 * 
	 * @return style
	 */
	public String getLabelStyle() {
		return "-fx-text-fill: #dddddd; -fx-font-size: 18px;";
	}	
}
