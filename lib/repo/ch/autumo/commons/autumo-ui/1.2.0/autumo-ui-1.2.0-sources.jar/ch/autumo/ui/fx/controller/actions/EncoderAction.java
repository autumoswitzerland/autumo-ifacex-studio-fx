/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.controller.actions;

import ch.autumo.commons.security.SecureApplication;
import ch.autumo.commons.utils.UtilsException;
import ch.autumo.commons.utils.security.CryptUtils;
import ch.autumo.ui.fx.BaseApp;
import ch.autumo.ui.fx.control.EncoderModes;
import ch.autumo.ui.utils.Helper;
import ch.autumo.ui.utils.UI;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;

/**
 * Encoder Action.
 */
public class EncoderAction extends BaseAction {

	private BaseApp app = null;
	private boolean internalEncryption = false;
	
	private TextField tpw = null;
	private TextField tval = null;
	private TextField tRaw = null;
	private ComboBox<String> cenc = null;
	/** The format of the encoded value: the legacy one (properties) or the structured one (yaml). */
	private ComboBox<String> cformat = null;
	
	private ObservableList<String> options = EncoderModes.getDefault();

	private boolean updatingEncoder = false;
	
	/** The formats the encoder can deliver: the legacy one and the structured one. */
	private static final String FORMAT_YAML = "yaml";
	private static final String FORMAT_PROPERTIES = "properties";
	
	/**
	 * Encoder action.
	 * 
	 * @param app the application
	 * @param internalEncryption <code>true</code> if you want to use
	 * 		the internal security key {@link SecureApplication#getInternalSecurityKey()} 
	 * 		and not the {@link SecureApplication#getUniqueSecurityKey()}
	 */
	public EncoderAction(BaseApp app, boolean internalEncryption) {
		this.app = app;
		this.internalEncryption = internalEncryption;
	}
	
	@Override
	public void execute() {
		
		int w1 = 120;
		int w2 = 496;
		int h = 25;
		
		final BorderPane pane = controller.getBody();
		BorderPane.setMargin(pane, new Insets(0, 12, 0, 12));
		pane.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		
		final GridPane grid = new GridPane();
		grid.setHgap(16);
		grid.setVgap(16);		
		grid.getStylesheets().add(Helper.getBaseStyle());
		// The dialog can be widened: the fields take the additional width.
		grid.setMaxWidth(Double.MAX_VALUE);
		final ColumnConstraints labelColumn = new ColumnConstraints();
		final ColumnConstraints valueColumn = new ColumnConstraints();
		valueColumn.setHgrow(Priority.ALWAYS);
		valueColumn.setFillWidth(true);
		final ColumnConstraints buttonColumn = new ColumnConstraints();
		grid.getColumnConstraints().addAll(labelColumn, valueColumn, buttonColumn);

		Label lpw = new Label(Helper.getTranslatedText(app, "Encoder.label.pw"));
		lpw.setMinWidth(w1);
		lpw.setPrefWidth(w1);
		lpw.setPrefHeight(h);
		
		tpw = new TextField();
		tpw.setStyle("-fx-background-color: #555555; -fx-text-fill: #dddddd;");
		tpw.setMinWidth(w2);
		tpw.setPrefWidth(w2);
		tpw.setMaxWidth(Double.MAX_VALUE);
		GridPane.setHgrow(tpw, Priority.ALWAYS);
		tpw.setPrefHeight(h);
		
		Label lval = new Label(Helper.getTranslatedText(app, "Encoder.label.value"));
		lval.setMinWidth(w1);
		lval.setPrefWidth(w1);
		lval.setPrefHeight(h);
		
		tval = new TextField();
		tval.setStyle("-fx-background-color: #555555; -fx-text-fill: #dddddd;");
		tval.setMinWidth(w2);
		tval.setPrefWidth(w2);
		tval.setMaxWidth(Double.MAX_VALUE);
		GridPane.setHgrow(tval, Priority.ALWAYS);
		tval.setPrefHeight(h);
		tval.setEditable(false);
		
		Label lRaw = new Label(Helper.getTranslatedText(app, "Encoder.label.raw"));
		lRaw.setMinWidth(w1);
		lRaw.setPrefWidth(w1);
		lRaw.setPrefHeight(h);
		
		tRaw = new TextField();
		tRaw.setStyle("-fx-background-color: #555555; -fx-text-fill: #dddddd;");
		tRaw.setMinWidth(w2);
		tRaw.setPrefWidth(w2);
		tRaw.setMaxWidth(Double.MAX_VALUE);
		GridPane.setHgrow(tRaw, Priority.ALWAYS);
		tRaw.setPrefHeight(h);
		tRaw.setEditable(false);
		
		Label lenc = new Label(Helper.getTranslatedText(app, "Encoder.label.enc"));
		lenc.setMinWidth(w1);
		lenc.setPrefWidth(w1);
		lenc.setPrefHeight(h);
		
		cenc = new ComboBox<>(options);
		cenc.setMinWidth(w2);
		cenc.setPrefWidth(w2);
		cenc.setMaxWidth(Double.MAX_VALUE);
		GridPane.setHgrow(cenc, Priority.ALWAYS);
		cenc.setPrefHeight(h);
		cenc.getSelectionModel().select(0);
		cenc.setOnAction(_ -> {
		    if (updatingEncoder) {
		        return;
		    }
		    encItemStateChanged(cenc.getValue());
		});
		
		Label lformat = new Label(Helper.getTranslatedText(app, "Encoder.label.format"));
		lformat.setMinWidth(w1);
		lformat.setPrefWidth(w1);
		lformat.setPrefHeight(h);
		
		cformat = new ComboBox<>(FXCollections.observableArrayList(FORMAT_YAML, FORMAT_PROPERTIES));
		cformat.setValue(FORMAT_YAML);
		cformat.setMinWidth(w2);
		cformat.setPrefWidth(w2);
		cformat.setMaxWidth(Double.MAX_VALUE);
		GridPane.setHgrow(cformat, Priority.ALWAYS);
		cformat.setPrefHeight(h);
		cformat.setOnAction(_ -> {
		    String selectedItem = cformat.getValue();
		    cformatItemStateChanged(selectedItem);
        });
		
		Button bCopy = new Button(Helper.getTranslatedText(app, "Encoder.button.copy"));
		bCopy.setStyle("-fx-background-color: #808080; -fx-text-fill: #dddddd;");
		bCopy.setPrefWidth(w1);
		bCopy.setPrefHeight(h);
		bCopy.setOnAction(_ -> {
            copy();
        });
		Button bCopyRaw = new Button(Helper.getTranslatedText(app, "Encoder.button.copy"));
		bCopyRaw.setStyle("-fx-background-color: #808080; -fx-text-fill: #dddddd;");
		bCopyRaw.setPrefWidth(w1);
		bCopyRaw.setPrefHeight(h);
		bCopyRaw.setOnAction(_ -> {
            copyRaw();
        });

		grid.add(lpw, 0, 0);
		grid.add(tpw, 1, 0);
		
		grid.add(lval, 0, 1);
		grid.add(tval, 1, 1);
		grid.add(bCopy, 2, 1);

		grid.add(lRaw, 0, 2);
		grid.add(tRaw, 1, 2);
		grid.add(bCopyRaw, 2, 2);
		
		grid.add(lenc, 0, 3);
		grid.add(cenc, 1, 3);
		
		grid.add(lformat, 0, 4);
		grid.add(cformat, 1, 4);
		
		pane.setCenter(grid);
	}

	private void copy() {
		final String str = tval.getText().trim();
		if (str.length() > 0) {
			Clipboard clipboard = Clipboard.getSystemClipboard();
			ClipboardContent content = new ClipboardContent();
		    content.putString(str);
		    clipboard.setContent(content);
	        tval.requestFocus();
		}
	}

	private void copyRaw() {
		final String str = tRaw.getText().trim();
		if (str.length() > 0) {
			Clipboard clipboard = Clipboard.getSystemClipboard();
			ClipboardContent content = new ClipboardContent();
		    content.putString(str);
		    clipboard.setContent(content);
	        tRaw.requestFocus();
		}
	}
	
	private void encItemStateChanged(String val) {
		if (val != null) {
			final String result = pw();
			if (result != null) { 
				// The value goes into the configuration as it is: the legacy notation or the
				// structured object of the new format.
				tval.setText(result);
				tRaw.setText(encoded(result));
			}
		}
	}
	
	private void cformatItemStateChanged(String val) {
		if (val != null) {
			final String result = pw();
			if (result != null) { 
				// The value goes into the configuration as it is: the legacy notation or the
				// structured object of the new format.
				tval.setText(result);
				tRaw.setText(encoded(result));
			}
		}
	}
	
	/**
	 * The encoded value as it goes into the configuration: the legacy notation
	 * ({@code {mode:value}}) or - for the new format - the structured object
	 * ({@code {enc: 3, value: "..." }}).
	 *
	 * @param encoded the encoded value
	 * @return the text for the configuration
	 */
	private String encoded(String encoded) {
		if (cformat == null || FORMAT_YAML.equals(cformat.getValue())) {
			final int mode = selectedMode();
			if (mode <= 0) {
				return encoded;
			}
			return "{enc: " + mode + ", value: \"" + encoded + "\"}";
		}
		return "{" + encoded + "}";
	}
	
	/** The selected encryption mode, 0 if none is selected. */
	private int selectedMode() {
		if (cenc == null || cenc.getValue() == null) {
			return 0;
		}
		final String val = cenc.getValue().toString();
		if (val.isBlank()) {
			return 0;
		}
		try {
			return Integer.parseInt(val.substring(0, 1));
		} catch (NumberFormatException e) {
			return 0;
		}
	}

	private String pw() {
		if (!internalEncryption && (app.getUniqueSecurityKey() == null || app.getUniqueSecurityKey().length() != 32)) {
			UI.showFineWarningDialog(
					app, 
					Helper.getTranslatedText(app, "Encoder.enc.err1")
				);
			updatingEncoder = true;
			try {
			    cenc.setItems(options);
			} finally {
			    updatingEncoder = false;
			}
			tval.setText("");
			tval.setEditable(true);
			tRaw.setText("");
			tRaw.setEditable(true);
    		return null;				
		}
		
		Object encObj = cenc.getValue();
		if (encObj == null) {
			cenc.setValue("0: none");
			return null;
		}
		
		final String enc = encObj.toString().substring(0, 1);
		int e = Integer.parseInt(enc);
		String val = tpw.getText();
		if ((val == null || val.length() == 0)) {
			cenc.setValue("0: none");
			return null;
		}
		
		String newVal = null;
		if (e == 0) {
			cenc.setItems(options);
			tval.setText("");
			tRaw.setText("");
			return null;
		} else {
			final ObservableList<String> tempOptions = FXCollections.observableArrayList(
					cenc.getValue().toString(),
					"0: none"
		    );
			updatingEncoder = true;
			try {
			    cenc.setItems(tempOptions);
			} finally {
			    updatingEncoder = false;
			}
			try {
				newVal = CryptUtils.encode(e, val, app, internalEncryption);
				if (FORMAT_YAML.equals(cformat.getValue()) && newVal != null && newVal.length() > 1) {
					newVal = newVal.substring(2, newVal.length());
				}
			} catch (UtilsException ex) {
				UI.showError(app, ex, Helper.getTranslatedText(app, "Encoder.enc.err2"));
			}
		}		
		return newVal;
	}
	
}
