/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.control;

import ch.autumo.ui.fx.listener.PasteCallback;
import javafx.scene.control.TextField;

/**
 * Search field.
 */
public class SearchField extends TextField {

	private PasteCallback callback = null;
	
	/**
	 * Create a search field.
	 */
	public SearchField() {
		super();
	}
	
	/**
	 * Create a search field.
	 * 
	 * @param text initial text
	 */
	public SearchField(String text) {
		super(text);
	}
			
	/**
	 * Create a search field with a paste callback.
	 * 
	 * @param callback paste callback
	 */
	public SearchField(PasteCallback callback) {
		this.callback = callback;
	}
	
	@Override
    public void paste() {
		this.callback.pasted();
		super.paste();
    }

	/**
	 * Get paste callback.
	 * 
	 * @return paste callback
	 */
	public PasteCallback getCallback() {
		return callback;
	}

	/**
	 * Set paste callback.
	 * 
	 * @param callback paste callback
	 */
	public void setCallback(PasteCallback callback) {
		this.callback = callback;
	}
	
}
