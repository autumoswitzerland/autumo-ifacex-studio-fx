/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.controller.actions.installer;

import ch.autumo.ui.utils.Helper;
import ch.autumo.ui.utils.UI.HyperLinkRedirectListener;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.web.WebView;

/**
 * About Installation Step.
 */
public class StepAbout extends BaseStep {

	/**
	 * Default constructor.
	 */
	public StepAbout() {
	}
	
	@Override
	public void execute() {
		
    	String lang = System.getProperty("user.language");
    	if (!Helper.isSupportedLang(lang))
    		lang = "en";
		
		final BorderPane pane = controller.getBody();
		// Individual insets, depending on the element that is placed!
		BorderPane.setMargin(pane, new Insets(0, 6, 0, 6));
		
		final GridPane grid = new GridPane();
		pane.setStyle("-fx-border-color: #555555");
		pane.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		
		final WebView webView = Helper.createWebView(app);
		webView.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		webView.getEngine().getLoadWorker().stateProperty().addListener(new HyperLinkRedirectListener(webView));
		
		webView.getEngine().setUserStyleSheetLocation(this.getHTMLStyleSheetLocation());
		
		webView.getEngine().load(Helper.getAppResource(app, "html/about_"+lang+".html"));
		
		GridPane.setVgrow(webView, Priority.ALWAYS);
		GridPane.setHgrow(webView, Priority.ALWAYS);
		
		Button next = controller.getFooterButton();
		next.setText(Helper.getTranslatedText(super.getApp(), "Installer.next"));
		next.setOnAction(_ -> {
			super.getInstallationController().next();
    	});
		
		grid.add(webView, 0, 0);
		pane.setCenter(grid);		
	}
	
	@Override
	public String getTitle() {
		return Helper.getTranslatedText(app, "About.title");
	}

	/**
	 * Returns the location of the HTML style sheet.
	 * Override to provide a custom style sheet.
	 *
	 * @return the CSS location
	 */
	public String getHTMLStyleSheetLocation() {
		return Helper.getBaseHTMLStyle();
	}

}
