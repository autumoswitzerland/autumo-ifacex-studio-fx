/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.controller.actions;

import java.util.ArrayList;

import ch.autumo.commons.versioning.Versions;
import ch.autumo.ui.utils.Helper;
import javafx.collections.FXCollections;
import javafx.scene.control.Button;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.util.Callback;


/**
 * Update Check Action.
 */
public class UpdateAction extends BaseAction {

	/**
	 * Default constructor.
	 */
	public UpdateAction() {
	}
	
	@Override
	public void execute() {

        final BorderPane pane = controller.getBody();
        pane.getChildren().clear();
    	
        final Versions versions = Helper.getWebVersions(app);
        
        boolean onlineAvailable = versions.isLoaded();
        
        final Versions.Version freeUpgradeVersion = versions.hasFreeUpgrade(app.getAppVersion());
        final Versions.Version upgradeVersion = versions.hasUpgrade(app.getAppVersion());
        boolean updateAvailable = upgradeVersion != null || freeUpgradeVersion !=null;
        
        final ListView<Control> list = new ListView<>();
        list.setStyle("-fx-background-color: transparent;");
        UpdateAction.this.setCellfactory(list);
        list.setPrefWidth(750.0);
		list.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        
        //list.setMouseTransparent( true );
        //list.setFocusTraversable( false );
		
        pane.setCenter(list);
        
        final ArrayList<Control> aList = new ArrayList<Control>();
        
        if (!onlineAvailable) {
            
        	aList.add(new Label(Helper.getTranslatedText(app, "Update.cannotcheck")));
            
        } else if (updateAvailable) {
            
            if (freeUpgradeVersion != null) {
                // free update
            	aList.add(new Label(Helper.getTranslatedText(app, "Update.available") + app.getAppTitle() + " " + freeUpgradeVersion.getTextValue() + "."));
            }
            
            if (upgradeVersion != null) {
                // with costs
            	aList.add(new Label(Helper.getTranslatedText(app, "Update.notavailable") + app.getAppTitle() + " " + upgradeVersion.getTextValue() + "."));
            }

        	aList.add(new Label("  "));
            
            final Button down = new Button(Helper.getTranslatedText(app, "Update.here"));
            down.setOnAction(_ -> {
            		Helper.openURL(app.getConfigurationParameter(ch.autumo.ui.Constants.CONFIG_ENTRY_URL_WEB_UPDATE));
            		controller.getStage().hide();
            	});
            down.setStyle("-fx-background-color: #555555;");
        	aList.add(down);
            
        } else {
        	
        	aList.add(new Label(Helper.getTranslatedText(app, "Update.nonewversion")));
        }
        
    	list.setItems(FXCollections.observableArrayList(aList));
	}
	
	private void setCellfactory(ListView<Control> list) {
		list.setCellFactory(new Callback<ListView<Control>, ListCell<Control>>() {
            @Override
            public ListCell<Control> call(ListView<Control> myObjectListView) {
                ListCell<Control> cell = new ListCell<Control>(){
                    @Override
                    protected void updateItem(Control myObject, boolean b) {
                        super.updateItem(myObject, b);
                		setTextFill(Color.WHITE);
                		setFont(new Font(14));
                        if(myObject != null) {
                        	if (myObject instanceof Label) {
                        		setText(((Label)myObject).getText());
                        		setStyle("-fx-text-fill: #dddddd; -fx-background-color: transparent;");
                        	}
                        	if (myObject instanceof Button) {
                        		setGraphic(myObject);
                        	}
                        }
                    }
                };
                cell.setStyle("-fx-background-color: transparent;");
                return cell;
            }
        });		
	}
	
}
