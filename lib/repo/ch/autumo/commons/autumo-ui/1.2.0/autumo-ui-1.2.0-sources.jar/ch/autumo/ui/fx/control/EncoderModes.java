/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.control;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Encryption mode constants for the encoder.
 */
public final class EncoderModes {

    /** Default list of encryption modes offered by the encoder (none / Base64-SHA3 / ...). */
    public static final ObservableList<String> DEFAULT = FXCollections.observableArrayList(
            "0: none",
            "1: Base64 - SHA3-256 AES",
            "2: Base64 - SHA-256 AES",
            "3: Base64 - PBE MD5 DES",
            "4: Blowfish"
    );

    private EncoderModes() {
    }

    /**
     * Returns the default encoding mode list.
     * 
     * @return observable list of encoding mode strings
     */
    public static ObservableList<String> getDefault() {
        return DEFAULT;
    }
}
