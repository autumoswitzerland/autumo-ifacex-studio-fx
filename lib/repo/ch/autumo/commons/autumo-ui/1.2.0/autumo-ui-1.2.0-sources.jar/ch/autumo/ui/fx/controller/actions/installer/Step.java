/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.controller.actions.installer;

import ch.autumo.ui.fx.BaseApp;

/**
 * Step interface for installer.
 */
public interface Step extends Comparable<Step>{

	/**
	 * Initialize step after creating a step with installation
	 * controller and application.
	 *  
	 * @param stepId the id of the step; 
	 * 		it defines the installation order of the steps 
	 * @param ic installation controller
	 * @param app application
	 */
    public void initialize(int stepId, InstallationController ic, BaseApp app);
	
    /**
     * Initialize for controller,
     */
    public void initialize();

    /**
     * Get the title for the installation step.
     * 
     * @return title
     */
    public String getTitle();
    
    /**
     * Get this step's number starting from 1.
     * 
     * @return step number
     */
    public int getStep();
    
    /**
     * Called when the step has been overtaken
     * by clicking the 'next' button.
     */
    public void steppedOver();
    
    /**
     * Is first step?
     * 
     * @return true if so
     */
    public boolean isFirst();
    
    /**
     * Is last step?
     * 
     * @return true if so
     */
    public boolean isLast();
    
}
