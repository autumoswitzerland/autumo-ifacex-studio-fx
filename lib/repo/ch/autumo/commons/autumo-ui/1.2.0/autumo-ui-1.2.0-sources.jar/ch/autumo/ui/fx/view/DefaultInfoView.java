/**
 * Copyright 2026 autumo GmbH, Michael Gasche.
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of autumo GmbH The intellectual and technical
 * concepts contained herein are proprietary to autumo GmbH
 * and are protected by trade secret or copyright law.
 *
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from autumo GmbH.
 */
package ch.autumo.ui.fx.view;

import ch.autumo.ui.fx.BaseApp;
import ch.autumo.ui.fx.controller.DefaultInfoController;
import ch.autumo.ui.fx.model.DefaultPaneModel;
import javafx.stage.Stage;

/**
 * Default Info Pane View.
 */
public class DefaultInfoView extends BaseBorderView {

    /**
     * Default Info Pane view.
     * 
     * @param app the application
     * @param stage stage
     */
    public DefaultInfoView(BaseApp app, Stage stage) {
    	this(app, stage, null);
    }
	
    /**
     * Default Info Pane view.
     * 
     * @param app the application
     * @param stage stage
     * @param styleResourcePath relative style ('style/style.css') file name or fully qualified resource path
     */
    public DefaultInfoView(BaseApp app, Stage stage, String styleResourcePath) {
    	super(app, stage, styleResourcePath);
    	final DefaultPaneModel model = new DefaultPaneModel(this);
    	this.setModel(model);
        this.setController(new DefaultInfoController(app, stage, model, this));
    }
	
}
